package com.tiaa.sample.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class HelloWorldService {

  public static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldService.class);
  
  public String getTitle(String name){
    
    LOGGER.info("Executing getTitle method.");
    
    if(StringUtils.isEmpty(name)){
      return "Hello World";
    } else {
      return "Hello "+name+" !!";
    }
  }
  
  public String getDesc() {
    LOGGER.info("Executing getDesc method.");
    
    return "First Maven Spring MVC application.";
  }
  
}
