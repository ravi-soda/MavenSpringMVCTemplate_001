package com.tiaa.sample.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tiaa.sample.service.HelloWorldService;

@Controller
public class HelloWorldController {
  
  @Autowired
  private HelloWorldService service;
  
  public static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldController.class);
  
  @RequestMapping(value="/", method=RequestMethod.GET)
  public String getMessage(Map<String, Object> model){
    
    LOGGER.info("Inside getMessage() method.");
    
    model.put("title", this.service.getTitle(""));
    model.put("desc", this.service.getDesc());
    
    return "index";
  }
  
  @RequestMapping(value="/hello/{name:.+}", method=RequestMethod.GET)
  public ModelAndView sayHello(@PathVariable String name){
    
    LOGGER.info("Inside sayHello() method.");
    
    ModelAndView model = new ModelAndView();
    
    model.setViewName("index");
    model.addObject("title", this.service.getTitle(name));
    model.addObject("desc", this.service.getDesc());
    
    return model;
  }
  
}
